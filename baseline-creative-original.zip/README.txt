BASELINE CREATIVE WEBSITE

1. Go to github.com and create a free account
2. Create a new repository called: baseline-creative
3. Upload all files in this folder
4. Go to Settings > Pages
5. Select main branch and save

Your site will be live at:
https://yourusername.github.io/baseline-creative
